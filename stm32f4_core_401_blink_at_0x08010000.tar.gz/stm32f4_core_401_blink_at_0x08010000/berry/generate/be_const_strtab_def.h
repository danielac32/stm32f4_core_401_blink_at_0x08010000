be_define_const_str(, "", 2166136261u, 0, 0, &be_const_str__X2Ep);
be_define_const_str(_X21_X3D, "!=", 2428715011u, 0, 2, &be_const_str_setbits);
be_define_const_str(_X28_X29, "()", 685372826u, 0, 2, &be_const_str_end);
be_define_const_str(_X2B, "+", 772578730u, 0, 1, &be_const_str_collect);
be_define_const_str(_X2E_X2E, "..", 2748622605u, 0, 2, &be_const_str___incr__);
be_define_const_str(_X2Elen, ".len", 850842136u, 0, 4, &be_const_str_raise);
be_define_const_str(_X2Ep, ".p", 1171526419u, 0, 2, &be_const_str_find);
be_define_const_str(_X2Esize, ".size", 1965188224u, 0, 5, NULL);
be_define_const_str(_X3D_X3D, "==", 2431966415u, 0, 2, &be_const_str_allocated);
be_define_const_str(__incr__, "__incr__", 3240913791u, 0, 8, &be_const_str_append);
be_define_const_str(__iterator__, "__iterator__", 3884039703u, 0, 12, &be_const_str_elif);
be_define_const_str(__lower__, "__lower__", 123855590u, 0, 9, NULL);
be_define_const_str(__upper__, "__upper__", 3612202883u, 0, 9, &be_const_str_fromstring);
be_define_const_str(_buffer, "_buffer", 2044888568u, 0, 7, &be_const_str_byte);
be_define_const_str(_change_buffer, "_change_buffer", 2101848693u, 0, 14, &be_const_str_classof);
be_define_const_str(abs, "abs", 709362235u, 0, 3, &be_const_str_type);
be_define_const_str(acos, "acos", 1006755615u, 0, 4, &be_const_str_asstring);
be_define_const_str(add, "add", 993596020u, 0, 3, &be_const_str_int);
be_define_const_str(allocated, "allocated", 429986098u, 0, 9, &be_const_str_bytes);
be_define_const_str(allocs, "allocs", 1254752255u, 0, 6, &be_const_str_classname);
be_define_const_str(append, "append", 110723809u, 0, 6, &be_const_str_varname);
be_define_const_str(as, "as", 1579491469u, 67, 2, &be_const_str_item);
be_define_const_str(asin, "asin", 4272848550u, 0, 4, &be_const_str_members);
be_define_const_str(assert, "assert", 2774883451u, 0, 6, &be_const_str_isdir);
be_define_const_str(asstring, "asstring", 1298225088u, 0, 8, &be_const_str_ceil);
be_define_const_str(atan, "atan", 108579519u, 0, 4, &be_const_str_size);
be_define_const_str(atan2, "atan2", 3173440503u, 0, 5, &be_const_str_getcwd);
be_define_const_str(attrdump, "attrdump", 1521571304u, 0, 8, &be_const_str_caller);
be_define_const_str(bool, "bool", 3365180733u, 0, 4, NULL);
be_define_const_str(break, "break", 3378807160u, 58, 5, &be_const_str_class);
be_define_const_str(byte, "byte", 1683620383u, 0, 4, &be_const_str_length_X20in_X20bits_X20must_X20be_X20between_X200_X20and_X2032);
be_define_const_str(bytes, "bytes", 1706151940u, 0, 5, &be_const_str_counters);
be_define_const_str(call, "call", 3018949801u, 0, 4, NULL);
be_define_const_str(calldepth, "calldepth", 3122364302u, 0, 9, &be_const_str_chdir);
be_define_const_str(caller, "caller", 1794178658u, 0, 6, NULL);
be_define_const_str(ceil, "ceil", 1659167240u, 0, 4, &be_const_str_count);
be_define_const_str(char, "char", 2823553821u, 0, 4, &be_const_str_exists);
be_define_const_str(chdir, "chdir", 806634853u, 0, 5, &be_const_str_listdir);
be_define_const_str(class, "class", 2872970239u, 57, 5, NULL);
be_define_const_str(classname, "classname", 1998589948u, 0, 9, &be_const_str_getbits);
be_define_const_str(classof, "classof", 1796577762u, 0, 7, &be_const_str_fromb64);
be_define_const_str(clear, "clear", 1550717474u, 0, 5, &be_const_str_isnan);
be_define_const_str(clock, "clock", 363073373u, 0, 5, &be_const_str_except);
be_define_const_str(codedump, "codedump", 1786337906u, 0, 8, &be_const_str_else);
be_define_const_str(collect, "collect", 2399039025u, 0, 7, &be_const_str_contains);
be_define_const_str(compile, "compile", 1000265118u, 0, 7, &be_const_str_pi);
be_define_const_str(concat, "concat", 4124019837u, 0, 6, &be_const_str_deinit);
be_define_const_str(contains, "contains", 1825239352u, 0, 8, NULL);
be_define_const_str(continue, "continue", 2977070660u, 59, 8, &be_const_str_issubclass);
be_define_const_str(copy, "copy", 3848464964u, 0, 4, &be_const_str_false);
be_define_const_str(cos, "cos", 4220379804u, 0, 3, &be_const_str_input);
be_define_const_str(cosh, "cosh", 4099687964u, 0, 4, NULL);
be_define_const_str(count, "count", 967958004u, 0, 5, &be_const_str_seti);
be_define_const_str(counters, "counters", 4095866864u, 0, 8, &be_const_str_tr);
be_define_const_str(def, "def", 3310976652u, 55, 3, &be_const_str_imax);
be_define_const_str(deg, "deg", 3327754271u, 0, 3, &be_const_str_do);
be_define_const_str(deinit, "deinit", 2345559592u, 0, 6, &be_const_str_sinh);
be_define_const_str(do, "do", 1646057492u, 65, 2, &be_const_str_frees);
be_define_const_str(dump, "dump", 3663001223u, 0, 4, &be_const_str_module);
be_define_const_str(elif, "elif", 3232090307u, 51, 4, &be_const_str_escape);
be_define_const_str(else, "else", 3183434736u, 52, 4, &be_const_str_floor);
be_define_const_str(end, "end", 1787721130u, 56, 3, &be_const_str_log10);
be_define_const_str(escape, "escape", 2652972038u, 0, 6, &be_const_str_system);
be_define_const_str(except, "except", 950914032u, 69, 6, &be_const_str_log);
be_define_const_str(exists, "exists", 1002329533u, 0, 6, &be_const_str_exit);
be_define_const_str(exit, "exit", 3454868101u, 0, 4, &be_const_str_real);
be_define_const_str(exp, "exp", 1923516200u, 0, 3, &be_const_str_if);
be_define_const_str(false, "false", 184981848u, 62, 5, NULL);
be_define_const_str(find, "find", 3186656602u, 0, 4, &be_const_str_insert);
be_define_const_str(floor, "floor", 3102149661u, 0, 5, &be_const_str_import);
be_define_const_str(for, "for", 2901640080u, 54, 3, &be_const_str_ismapped);
be_define_const_str(format, "format", 3114108242u, 0, 6, NULL);
be_define_const_str(frees, "frees", 2655040120u, 0, 5, NULL);
be_define_const_str(fromb64, "fromb64", 2717019639u, 0, 7, &be_const_str_geti);
be_define_const_str(fromhex, "fromhex", 1847150394u, 0, 7, &be_const_str_range);
be_define_const_str(fromptr, "fromptr", 666189689u, 0, 7, &be_const_str_ismethod);
be_define_const_str(fromstring, "fromstring", 610302344u, 0, 10, &be_const_str_init);
be_define_const_str(gcdebug, "gcdebug", 227911486u, 0, 7, NULL);
be_define_const_str(get, "get", 1410115415u, 0, 3, &be_const_str_hex);
be_define_const_str(getbits, "getbits", 3094168979u, 0, 7, &be_const_str_setmodule);
be_define_const_str(getcwd, "getcwd", 652026575u, 0, 6, NULL);
be_define_const_str(getfloat, "getfloat", 2820979603u, 0, 8, NULL);
be_define_const_str(geti, "geti", 2381006490u, 0, 4, NULL);
be_define_const_str(hex, "hex", 4273249610u, 0, 3, &be_const_str_static);
be_define_const_str(if, "if", 959999494u, 50, 2, NULL);
be_define_const_str(imax, "imax", 3084515410u, 0, 4, &be_const_str_time);
be_define_const_str(imin, "imin", 2714127864u, 0, 4, NULL);
be_define_const_str(import, "import", 288002260u, 66, 6, &be_const_str_sqrt);
be_define_const_str(incr, "incr", 482404207u, 0, 4, &be_const_str_setrange);
be_define_const_str(init, "init", 380752755u, 0, 4, &be_const_str_resize);
be_define_const_str(input, "input", 4191711099u, 0, 5, &be_const_str_tohex);
be_define_const_str(insert, "insert", 3332609576u, 0, 6, &be_const_str_print);
be_define_const_str(int, "int", 2515107422u, 0, 3, &be_const_str_mkdir);
be_define_const_str(isdir, "isdir", 2340917412u, 0, 5, NULL);
be_define_const_str(isfile, "isfile", 3131505107u, 0, 6, NULL);
be_define_const_str(isinstance, "isinstance", 3669352738u, 0, 10, &be_const_str_tostring);
be_define_const_str(ismapped, "ismapped", 2725004770u, 0, 8, &be_const_str_solidified);
be_define_const_str(ismethod, "ismethod", 3513438880u, 0, 8, NULL);
be_define_const_str(isnan, "isnan", 2981347434u, 0, 5, NULL);
be_define_const_str(issubclass, "issubclass", 4078395519u, 0, 10, &be_const_str_true);
be_define_const_str(item, "item", 2671260646u, 0, 4, NULL);
be_define_const_str(iter, "iter", 3124256359u, 0, 4, &be_const_str_name);
be_define_const_str(join, "join", 3374496889u, 0, 4, NULL);
be_define_const_str(keys, "keys", 4182378701u, 0, 4, &be_const_str_try);
be_define_const_str(length_X20in_X20bits_X20must_X20be_X20between_X200_X20and_X2032, "length in bits must be between 0 and 32", 2584509128u, 0, 39, NULL);
be_define_const_str(list, "list", 217798785u, 0, 4, &be_const_str_pow);
be_define_const_str(listdir, "listdir", 2005220720u, 0, 7, &be_const_str_lower);
be_define_const_str(load, "load", 3859241449u, 0, 4, &be_const_str_member);
be_define_const_str(log, "log", 1062293841u, 0, 3, &be_const_str_map);
be_define_const_str(log10, "log10", 2346846000u, 0, 5, &be_const_str_traceback);
be_define_const_str(lower, "lower", 3038577850u, 0, 5, &be_const_str_reverse);
be_define_const_str(map, "map", 3751997361u, 0, 3, &be_const_str_tan);
be_define_const_str(member, "member", 719708611u, 0, 6, &be_const_str_replace);
be_define_const_str(members, "members", 937576464u, 0, 7, NULL);
be_define_const_str(mkdir, "mkdir", 2883839448u, 0, 5, NULL);
be_define_const_str(module, "module", 3617558685u, 0, 6, NULL);
be_define_const_str(name, "name", 2369371622u, 0, 4, &be_const_str_set);
be_define_const_str(nan, "nan", 797905850u, 0, 3, NULL);
be_define_const_str(nil, "nil", 228849900u, 63, 3, &be_const_str_pop);
be_define_const_str(number, "number", 467038368u, 0, 6, NULL);
be_define_const_str(open, "open", 3546203337u, 0, 4, NULL);
be_define_const_str(path, "path", 2223459638u, 0, 4, &be_const_str_while);
be_define_const_str(pi, "pi", 1213090802u, 0, 2, &be_const_str_rad);
be_define_const_str(pop, "pop", 1362321360u, 0, 3, &be_const_str_reallocs);
be_define_const_str(pow, "pow", 1479764693u, 0, 3, &be_const_str_return);
be_define_const_str(print, "print", 372738696u, 0, 5, NULL);
be_define_const_str(push, "push", 2272264157u, 0, 4, &be_const_str_str);
be_define_const_str(rad, "rad", 1358899048u, 0, 3, NULL);
be_define_const_str(raise, "raise", 1593437475u, 70, 5, NULL);
be_define_const_str(rand, "rand", 2711325910u, 0, 4, NULL);
be_define_const_str(range, "range", 4208725202u, 0, 5, NULL);
be_define_const_str(real, "real", 3604983901u, 0, 4, &be_const_str_remove);
be_define_const_str(reallocs, "reallocs", 535567874u, 0, 8, &be_const_str_setfloat);
be_define_const_str(remove, "remove", 3683784189u, 0, 6, NULL);
be_define_const_str(replace, "replace", 2704835779u, 0, 7, &be_const_str_setitem);
be_define_const_str(resize, "resize", 3514612129u, 0, 6, NULL);
be_define_const_str(return, "return", 2246981567u, 60, 6, NULL);
be_define_const_str(reverse, "reverse", 558918661u, 0, 7, NULL);
be_define_const_str(set, "set", 3324446467u, 0, 3, NULL);
be_define_const_str(setbits, "setbits", 2762408167u, 0, 7, NULL);
be_define_const_str(setbytes, "setbytes", 197507254u, 0, 8, &be_const_str_upvname);
be_define_const_str(setfloat, "setfloat", 2799488807u, 0, 8, NULL);
be_define_const_str(seti, "seti", 1500556254u, 0, 4, NULL);
be_define_const_str(setitem, "setitem", 1554834596u, 0, 7, &be_const_str_split);
be_define_const_str(setmember, "setmember", 1432909441u, 0, 9, &be_const_str_top);
be_define_const_str(setmodule, "setmodule", 2354663567u, 0, 9, NULL);
be_define_const_str(setrange, "setrange", 3794019032u, 0, 8, &be_const_str_upper);
be_define_const_str(sin, "sin", 3761252941u, 0, 3, NULL);
be_define_const_str(sinh, "sinh", 282220607u, 0, 4, NULL);
be_define_const_str(size, "size", 597743964u, 0, 4, NULL);
be_define_const_str(solidified, "solidified", 3257553487u, 0, 10, &be_const_str_tanh);
be_define_const_str(split, "split", 2276994531u, 0, 5, &be_const_str_var);
be_define_const_str(splitext, "splitext", 2150391934u, 0, 8, NULL);
be_define_const_str(sqrt, "sqrt", 2112764879u, 0, 4, NULL);
be_define_const_str(srand, "srand", 465518633u, 0, 5, &be_const_str_super);
be_define_const_str(static, "static", 3532702267u, 71, 6, NULL);
be_define_const_str(str, "str", 3259748752u, 0, 3, &be_const_str_tobool);
be_define_const_str(super, "super", 4152230356u, 0, 5, NULL);
be_define_const_str(system, "system", 1226705564u, 0, 6, &be_const_str_tob64);
be_define_const_str(tan, "tan", 2633446552u, 0, 3, NULL);
be_define_const_str(tanh, "tanh", 153638352u, 0, 4, NULL);
be_define_const_str(time, "time", 1564253156u, 0, 4, NULL);
be_define_const_str(tob64, "tob64", 373777640u, 0, 5, NULL);
be_define_const_str(tobool, "tobool", 2436909084u, 0, 6, NULL);
be_define_const_str(tohex, "tohex", 1583935793u, 0, 5, &be_const_str_toptr);
be_define_const_str(tolower, "tolower", 1042520049u, 0, 7, &be_const_str_toupper);
be_define_const_str(top, "top", 2802900028u, 0, 3, NULL);
be_define_const_str(toptr, "toptr", 3379847454u, 0, 5, NULL);
be_define_const_str(tostring, "tostring", 2299708645u, 0, 8, NULL);
be_define_const_str(toupper, "toupper", 3691983576u, 0, 7, NULL);
be_define_const_str(tr, "tr", 1195724803u, 0, 2, NULL);
be_define_const_str(traceback, "traceback", 3385188109u, 0, 9, NULL);
be_define_const_str(true, "true", 1303515621u, 61, 4, NULL);
be_define_const_str(try, "try", 2887626766u, 68, 3, NULL);
be_define_const_str(type, "type", 1361572173u, 0, 4, NULL);
be_define_const_str(upper, "upper", 176974407u, 0, 5, NULL);
be_define_const_str(upvname, "upvname", 3848760617u, 0, 7, NULL);
be_define_const_str(value_error, "value_error", 773297791u, 0, 11, NULL);
be_define_const_str(var, "var", 2317739966u, 64, 3, NULL);
be_define_const_str(varname, "varname", 2273276445u, 0, 7, NULL);
be_define_const_str(while, "while", 231090382u, 53, 5, NULL);


/* weak strings */

static const bstring* const m_string_table[] = {
    (const bstring *)&be_const_str__X3D_X3D,
    (const bstring *)&be_const_str_isinstance,
    NULL,
    NULL,
    (const bstring *)&be_const_str_nan,
    (const bstring *)&be_const_str_splitext,
    (const bstring *)&be_const_str_number,
    (const bstring *)&be_const_str_dump,
    NULL,
    (const bstring *)&be_const_str_clear,
    (const bstring *)&be_const_str___upper__,
    (const bstring *)&be_const_str_rand,
    (const bstring *)&be_const_str_isfile,
    (const bstring *)&be_const_str_cos,
    (const bstring *)&be_const_str_nil,
    (const bstring *)&be_const_str_setmember,
    (const bstring *)&be_const_str__X2E_X2E,
    (const bstring *)&be_const_str_get,
    (const bstring *)&be_const_str_codedump,
    NULL,
    (const bstring *)&be_const_str_attrdump,
    (const bstring *)&be_const_str_for,
    (const bstring *)&be_const_str___lower__,
    (const bstring *)&be_const_str_atan,
    (const bstring *)&be_const_str__X2Esize,
    (const bstring *)&be_const_str_tolower,
    (const bstring *)&be_const_str_exp,
    (const bstring *)&be_const_str_,
    (const bstring *)&be_const_str_cosh,
    (const bstring *)&be_const_str_incr,
    (const bstring *)&be_const_str_copy,
    (const bstring *)&be_const_str__X28_X29,
    NULL,
    (const bstring *)&be_const_str__buffer,
    (const bstring *)&be_const_str_push,
    (const bstring *)&be_const_str_call,
    NULL,
    (const bstring *)&be_const_str_bool,
    (const bstring *)&be_const_str_clock,
    (const bstring *)&be_const_str_join,
    (const bstring *)&be_const_str_asin,
    (const bstring *)&be_const_str_gcdebug,
    (const bstring *)&be_const_str___iterator__,
    (const bstring *)&be_const_str_keys,
    (const bstring *)&be_const_str_fromhex,
    (const bstring *)&be_const_str_getfloat,
    (const bstring *)&be_const_str_load,
    (const bstring *)&be_const_str__X2B,
    (const bstring *)&be_const_str_char,
    (const bstring *)&be_const_str__X2Elen,
    (const bstring *)&be_const_str_value_error,
    (const bstring *)&be_const_str_list,
    (const bstring *)&be_const_str__change_buffer,
    (const bstring *)&be_const_str_format,
    NULL,
    NULL,
    (const bstring *)&be_const_str_path,
    (const bstring *)&be_const_str_sin,
    (const bstring *)&be_const_str_continue,
    (const bstring *)&be_const_str_concat,
    (const bstring *)&be_const_str_calldepth,
    (const bstring *)&be_const_str_compile,
    (const bstring *)&be_const_str_deg,
    (const bstring *)&be_const_str_abs,
    (const bstring *)&be_const_str_add,
    (const bstring *)&be_const_str_setbytes,
    (const bstring *)&be_const_str_open,
    (const bstring *)&be_const_str_iter,
    (const bstring *)&be_const_str_def,
    (const bstring *)&be_const_str_fromptr,
    (const bstring *)&be_const_str_break,
    (const bstring *)&be_const_str_as,
    (const bstring *)&be_const_str_imin,
    (const bstring *)&be_const_str_srand,
    (const bstring *)&be_const_str_allocs,
    (const bstring *)&be_const_str_atan2,
    (const bstring *)&be_const_str_acos,
    (const bstring *)&be_const_str_assert,
    (const bstring *)&be_const_str__X21_X3D
};

static const struct bconststrtab m_const_string_table = {
    .size = 79,
    .count = 181,
    .table = m_string_table
};
