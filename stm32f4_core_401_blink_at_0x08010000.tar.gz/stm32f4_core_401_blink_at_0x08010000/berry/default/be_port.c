/********************************************************************
** Copyright (c) 2018-2020 Guan Wenliang
** This file is part of the Berry default interpreter.
** skiars@qq.com, https://github.com/Skiars/berry
** See Copyright Notice in the LICENSE file or at
** https://github.com/Skiars/berry/blob/master/LICENSE
********************************************************************/
#include "berry.h"
#include "be_mem.h"
#include "be_sys.h"
#include <stdio.h>
#include <string.h>

/* this file contains configuration for the file system. */

/* standard input and output */

BERRY_API void be_writebuffer(const char *buffer, size_t length)
{
    //be_fwrite(stdout, buffer, length);
}

BERRY_API char* be_readstring(char *buffer, size_t size)
{
    return  0;//be_fgets(stdin, buffer, (int)size);
}

 

void* be_fopen(const char *filename, const char *modes)
{
    return 0;//fopen(filename, modes);
}

int be_fclose(void *hfile)
{
    return 0;//fclose(hfile);
}

size_t be_fwrite(void *hfile, const void *buffer, size_t length)
{
    return 0;//fwrite(buffer, 1, length, hfile);
}

size_t be_fread(void *hfile, void *buffer, size_t length)
{
    return 0;//fread(buffer, 1, length, hfile);
}

char* be_fgets(void *hfile, void *buffer, int size)
{
    return 0;//fgets(buffer, size, hfile);
}

int be_fseek(void *hfile, long offset)
{
    return 0;//fseek(hfile, offset, SEEK_SET);
}

long int be_ftell(void *hfile)
{
    return 0;//ftell(hfile);
}

long int be_fflush(void *hfile)
{
    return 0;//fflush(hfile);
}

size_t be_fsize(void *hfile)
{
    /*long int size, offset = be_ftell(hfile);
    fseek(hfile, 0L, SEEK_END);
    size = ftell(hfile);
    fseek(hfile, offset, SEEK_SET);
    return size;*/
    return 0;//
}



 

#if BE_USE_FILE_SYSTEM
 

//#include <dirent.h>
//#include <unistd.h>
//#include <sys/stat.h>

int be_isdir(const char *path)
{
    //struct stat path_stat;
    //int res = stat(path, &path_stat);
    return 0;//res == 0 && S_ISDIR(path_stat.st_mode);
}

int be_isfile(const char *path)
{
    //struct stat path_stat;
    //int res = stat(path, &path_stat);
    return 0;//res == 0 && !S_ISDIR(path_stat.st_mode);
}

int be_isexist(const char *path)
{
    //struct stat path_stat;
    return 0;//stat(path, &path_stat) == 0;
}

char* be_getcwd(char *buf, size_t size)
{
    return 0;//getcwd(buf, size);
}

int be_chdir(const char *path)
{
    return 0;//chdir(path);
}

int be_mkdir(const char *path)
{
 
    return 0;//mkdir(path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
 
}

int be_unlink(const char *filename)
{
    return 0;//remove(filename);
}

int be_dirfirst(bdirinfo *info, const char *path)
{
    /*info->dir = opendir(path);
    if (info->dir) {
        return be_dirnext(info);
    }*/
    return 1;
}

int be_dirnext(bdirinfo *info)
{
    /*struct dirent *file;
    info->file = file = readdir(info->dir);
    if (file) {
        info->name = file->d_name;
        return 0;
    }*/
    return 1;
}

int be_dirclose(bdirinfo *info)
{
    return 0;//closedir(info->dir) != 0;
}

 
#endif /* BE_USE_OS_MODULE || BE_USE_FILE_SYSTEM */
